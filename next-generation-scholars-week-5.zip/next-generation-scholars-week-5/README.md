# next-generation-scholars
## Intro to Web - Week 5
In this course, we will go over the basics of how to build a basic website written in Hyper Text Markup Language (HTML), style your HTML with Cascading Style Sheets (CSS), and add some functionality in Javascript. 
We've broken down the class in two sections; building a responsive website and building a website for your parent(s) or someone you know.
For the last week, we will spend time on understanding how to publish your site on the cloud with Heroku.

---

### Instructors

Boi Soth
Tomera Ten

Email: ngs@spammusubeats.com

### Class resource directory & assignments
[NGS Google Drive - Week 5](https://drive.google.com/open?id=14md1H259fI7g0STSvmRqlyekUWVE6WIv)

---

## Week 5 - Layout Deep Dive - Modular

[Week 5 Slides](https://docs.google.com/presentation/d/1uexq88Bwq3qt6QMFAbrHqSGr3Y_lKU_blcBHim9mvhQ/edit?usp=sharing)



